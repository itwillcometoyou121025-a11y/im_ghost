require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const path = require('path');
const fs = require('fs').promises;

// Import modules
const TelegramBot = require('./bot/TelegramBot');
const Database = require('./database/Database');
const WebServer = require('./web/WebServer');
const MonitoringService = require('./services/MonitoringService');
const FileManagerService = require('./services/FileManagerService');
const NotificationService = require('./services/NotificationService');
const Logger = require('./utils/Logger');

class Application {
    constructor() {
        this.app = express();
        this.port = process.env.PORT || 3000;
        this.logger = new Logger();
        this.isProduction = process.env.NODE_ENV === 'production';
    }

    async initialize() {
        try {
            this.logger.info('🚀 Starting Telegram Monitoring Bot...');
            
            // Ensure data directory exists
            await this.ensureDataDirectory();
            
            // Initialize database
            this.database = new Database();
            await this.database.initialize();
            
            // Initialize services
            this.fileManager = new FileManagerService(this.database);
            this.notificationService = new NotificationService();
            this.monitoringService = new MonitoringService(this.database, this.notificationService);
            
            // Initialize Telegram bot
            this.telegramBot = new TelegramBot(
                this.database,
                this.fileManager,
                this.monitoringService,
                this.notificationService
            );
            
            // Setup Express middleware
            this.setupMiddleware();
            
            // Initialize web server
            this.webServer = new WebServer(
                this.app,
                this.database,
                this.telegramBot,
                this.monitoringService
            );
            
            // Start services
            await this.start();
            
        } catch (error) {
            this.logger.error('Failed to initialize application:', error);
            process.exit(1);
        }
    }
    
    setupMiddleware() {
        // Security middleware
        this.app.use(helmet({
            contentSecurityPolicy: false // Disable for development
        }));
        
        // CORS configuration
        this.app.use(cors({
            origin: process.env.CORS_ORIGIN || '*',
            credentials: true
        }));
        
        // Body parsing middleware
        this.app.use(express.json({ limit: '50mb' }));
        this.app.use(express.urlencoded({ extended: true, limit: '50mb' }));
        
        // Compression middleware
        this.app.use(compression());
        
        // Static files
        this.app.use('/uploads', express.static(path.join(__dirname, '../uploads')));
        this.app.use('/public', express.static(path.join(__dirname, '../public')));
        
        // Request logging
        this.app.use((req, res, next) => {
            this.logger.debug(`${req.method} ${req.path}`);
            next();
        });
    }
    
    async ensureDataDirectory() {
        const dataPath = path.join(__dirname, '../data');
        const uploadsPath = path.join(__dirname, '../uploads');
        const publicPath = path.join(__dirname, '../public');
        
        for (const dir of [dataPath, uploadsPath, publicPath]) {
            try {
                await fs.access(dir);
            } catch {
                await fs.mkdir(dir, { recursive: true });
                this.logger.info(`Created directory: ${dir}`);
            }
        }
    }
    
    async start() {
        // Start Telegram bot
        await this.telegramBot.start();
        
        // Start monitoring service
        if (process.env.ENABLE_MONITORING === 'true') {
            await this.monitoringService.start();
        }
        
        // Start web server
        this.server = this.app.listen(this.port, () => {
            this.logger.info(`✅ Server running on port ${this.port}`);
            this.logger.info(`📱 Telegram bot is active`);
            this.logger.info(`🌐 Web dashboard available at http://localhost:${this.port}`);
            
            if (this.isProduction) {
                this.logger.info(`🚀 Running in PRODUCTION mode`);
                this.logger.info(`Webhook URL: ${process.env.WEBHOOK_URL}`);
            } else {
                this.logger.info(`🔧 Running in DEVELOPMENT mode`);
            }
        });
        
        // Graceful shutdown
        this.setupGracefulShutdown();
    }
    
    setupGracefulShutdown() {
        const shutdown = async (signal) => {
            this.logger.info(`${signal} received, shutting down gracefully...`);
            
            // Stop accepting new connections
            if (this.server) {
                this.server.close(() => {
                    this.logger.info('HTTP server closed');
                });
            }
            
            // Stop services
            if (this.telegramBot) await this.telegramBot.stop();
            if (this.monitoringService) await this.monitoringService.stop();
            if (this.database) await this.database.close();
            
            this.logger.info('Shutdown complete');
            process.exit(0);
        };
        
        process.on('SIGTERM', () => shutdown('SIGTERM'));
        process.on('SIGINT', () => shutdown('SIGINT'));
    }
}

// Start application
const app = new Application();
app.initialize().catch(error => {
    console.error('Fatal error:', error);
    process.exit(1);
});