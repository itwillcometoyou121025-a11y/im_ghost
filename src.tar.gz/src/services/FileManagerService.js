const fs = require('fs').promises;
const path = require('path');
const axios = require('axios');
const Logger = require('../utils/Logger');

class FileManagerService {
    constructor(database) {
        this.database = database;
        this.logger = new Logger();
        this.uploadsDir = path.join(__dirname, '../../uploads');
    }
    
    async listDirectory(dirPath) {
        try {
            // Security: prevent directory traversal
            const safePath = path.resolve(dirPath);
            if (!safePath.startsWith('/')) {
                throw new Error('Invalid path');
            }
            
            const files = await fs.readdir(safePath);
            const fileDetails = [];
            
            for (const file of files) {
                try {
                    const filePath = path.join(safePath, file);
                    const stat = await fs.stat(filePath);
                    
                    fileDetails.push({
                        name: file,
                        path: filePath,
                        isDirectory: stat.isDirectory(),
                        size: stat.size,
                        modified: stat.mtime
                    });
                } catch (err) {
                    // Skip files we can't access
                    continue;
                }
            }
            
            // Sort directories first, then files
            fileDetails.sort((a, b) => {
                if (a.isDirectory && !b.isDirectory) return -1;
                if (!a.isDirectory && b.isDirectory) return 1;
                return a.name.localeCompare(b.name);
            });
            
            return fileDetails;
            
        } catch (error) {
            this.logger.error('Failed to list directory:', error);
            return [];
        }
    }
    
    async getFileInfo(filePath) {
        try {
            const safePath = path.resolve(filePath);
            const stat = await fs.stat(safePath);
            
            return {
                name: path.basename(safePath),
                path: safePath,
                size: stat.size,
                isDirectory: stat.isDirectory(),
                created: stat.birthtime,
                modified: stat.mtime,
                accessed: stat.atime
            };
            
        } catch (error) {
            this.logger.error('Failed to get file info:', error);
            throw error;
        }
    }
    
    async readFile(filePath) {
        try {
            const safePath = path.resolve(filePath);
            const content = await fs.readFile(safePath, 'utf8');
            return content;
            
        } catch (error) {
            this.logger.error('Failed to read file:', error);
            throw error;
        }
    }
    
    async sendFile(chatId, filePath, bot) {
        try {
            const safePath = path.resolve(filePath);
            const stat = await fs.stat(safePath);
            
            // Check file size limit (50MB for Telegram)
            if (stat.size > 50 * 1024 * 1024) {
                await bot.sendMessage(chatId, '❌ File too large (max 50MB)');
                return;
            }
            
            // Send file based on type
            const ext = path.extname(safePath).toLowerCase();
            const filename = path.basename(safePath);
            
            if (['.jpg', '.jpeg', '.png', '.gif'].includes(ext)) {
                await bot.sendPhoto(chatId, safePath, {
                    caption: filename
                });
            } else if (['.mp4', '.avi', '.mov'].includes(ext)) {
                await bot.sendVideo(chatId, safePath, {
                    caption: filename
                });
            } else if (['.mp3', '.wav', '.ogg'].includes(ext)) {
                await bot.sendAudio(chatId, safePath, {
                    caption: filename
                });
            } else {
                await bot.sendDocument(chatId, safePath, {
                    caption: filename
                });
            }
            
            // Log file access
            await this.database.logActivity('file_download', {
                path: safePath,
                filename,
                size: stat.size
            });
            
        } catch (error) {
            this.logger.error('Failed to send file:', error);
            await bot.sendMessage(chatId, '❌ Failed to send file');
        }
    }
    
    async deleteFile(filePath) {
        try {
            const safePath = path.resolve(filePath);
            const stat = await fs.stat(safePath);
            
            if (stat.isDirectory()) {
                await fs.rmdir(safePath, { recursive: true });
            } else {
                await fs.unlink(safePath);
            }
            
            // Log deletion
            await this.database.logActivity('file_delete', {
                path: safePath,
                isDirectory: stat.isDirectory()
            });
            
            return true;
            
        } catch (error) {
            this.logger.error('Failed to delete file:', error);
            throw error;
        }
    }
    
    async createDirectory(dirPath) {
        try {
            const safePath = path.resolve(dirPath);
            await fs.mkdir(safePath, { recursive: true });
            
            // Log creation
            await this.database.logActivity('directory_create', {
                path: safePath
            });
            
            return true;
            
        } catch (error) {
            this.logger.error('Failed to create directory:', error);
            throw error;
        }
    }
    
    async moveFile(sourcePath, destPath) {
        try {
            const safeSource = path.resolve(sourcePath);
            const safeDest = path.resolve(destPath);
            
            await fs.rename(safeSource, safeDest);
            
            // Log move operation
            await this.database.logActivity('file_move', {
                source: safeSource,
                destination: safeDest
            });
            
            return true;
            
        } catch (error) {
            this.logger.error('Failed to move file:', error);
            throw error;
        }
    }
    
    async copyFile(sourcePath, destPath) {
        try {
            const safeSource = path.resolve(sourcePath);
            const safeDest = path.resolve(destPath);
            
            await fs.copyFile(safeSource, safeDest);
            
            // Log copy operation
            await this.database.logActivity('file_copy', {
                source: safeSource,
                destination: safeDest
            });
            
            return true;
            
        } catch (error) {
            this.logger.error('Failed to copy file:', error);
            throw error;
        }
    }
    
    async saveUploadedFile(fileUrl, filename) {
        try {
            // Ensure uploads directory exists
            await fs.mkdir(this.uploadsDir, { recursive: true });
            
            const filePath = path.join(this.uploadsDir, filename);
            
            // Download file from URL
            const response = await axios({
                method: 'GET',
                url: fileUrl,
                responseType: 'stream'
            });
            
            // Save to file
            const writer = require('fs').createWriteStream(filePath);
            response.data.pipe(writer);
            
            return new Promise((resolve, reject) => {
                writer.on('finish', async () => {
                    const stat = await fs.stat(filePath);
                    
                    // Save to database
                    await this.database.saveFile(
                        filename,
                        filePath,
                        stat.size,
                        path.extname(filename)
                    );
                    
                    resolve(filePath);
                });
                writer.on('error', reject);
            });
            
        } catch (error) {
            this.logger.error('Failed to save uploaded file:', error);
            throw error;
        }
    }
    
    async searchFiles(searchPath, pattern) {
        try {
            const results = [];
            
            async function search(dir) {
                const files = await fs.readdir(dir);
                
                for (const file of files) {
                    const filePath = path.join(dir, file);
                    
                    try {
                        const stat = await fs.stat(filePath);
                        
                        if (file.toLowerCase().includes(pattern.toLowerCase())) {
                            results.push({
                                name: file,
                                path: filePath,
                                isDirectory: stat.isDirectory(),
                                size: stat.size
                            });
                        }
                        
                        if (stat.isDirectory() && results.length < 100) {
                            await search(filePath);
                        }
                    } catch (err) {
                        // Skip files we can't access
                        continue;
                    }
                }
            }
            
            await search(searchPath);
            return results.slice(0, 50); // Limit results
            
        } catch (error) {
            this.logger.error('Failed to search files:', error);
            return [];
        }
    }
    
    async getStorageInfo() {
        try {
            const si = require('systeminformation');
            const disks = await si.fsSize();
            
            return disks.map(disk => ({
                fs: disk.fs,
                type: disk.type,
                size: disk.size,
                used: disk.used,
                available: disk.available,
                use: disk.use,
                mount: disk.mount
            }));
            
        } catch (error) {
            this.logger.error('Failed to get storage info:', error);
            return [];
        }
    }
    
    async compressFiles(filePaths, outputPath) {
        try {
            const archiver = require('archiver');
            const output = require('fs').createWriteStream(outputPath);
            const archive = archiver('zip', {
                zlib: { level: 9 } // Maximum compression
            });
            
            return new Promise((resolve, reject) => {
                output.on('close', () => {
                    resolve({
                        path: outputPath,
                        size: archive.pointer()
                    });
                });
                
                archive.on('error', reject);
                archive.pipe(output);
                
                for (const filePath of filePaths) {
                    const safePath = path.resolve(filePath);
                    const name = path.basename(safePath);
                    archive.file(safePath, { name });
                }
                
                archive.finalize();
            });
            
        } catch (error) {
            this.logger.error('Failed to compress files:', error);
            throw error;
        }
    }
}

module.exports = FileManagerService;