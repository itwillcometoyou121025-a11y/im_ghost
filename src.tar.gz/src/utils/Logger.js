const winston = require('winston');
const path = require('path');
const fs = require('fs');

class Logger {
    constructor() {
        // Ensure logs directory exists
        const logsDir = path.join(__dirname, '../../logs');
        if (!fs.existsSync(logsDir)) {
            fs.mkdirSync(logsDir, { recursive: true });
        }
        
        // Create winston logger instance
        this.logger = winston.createLogger({
            level: process.env.LOG_LEVEL || 'info',
            format: winston.format.combine(
                winston.format.timestamp({
                    format: 'YYYY-MM-DD HH:mm:ss'
                }),
                winston.format.errors({ stack: true }),
                winston.format.splat(),
                winston.format.json()
            ),
            defaultMeta: { service: 'telegram-monitoring-bot' },
            transports: [
                // Write all logs with level 'error' and below to error.log
                new winston.transports.File({
                    filename: path.join(logsDir, 'error.log'),
                    level: 'error',
                    maxsize: 5242880, // 5MB
                    maxFiles: 5
                }),
                // Write all logs with level 'info' and below to combined.log
                new winston.transports.File({
                    filename: path.join(logsDir, 'combined.log'),
                    maxsize: 5242880, // 5MB
                    maxFiles: 10
                })
            ]
        });
        
        // If not in production, log to console too
        if (process.env.NODE_ENV !== 'production') {
            this.logger.add(new winston.transports.Console({
                format: winston.format.combine(
                    winston.format.colorize(),
                    winston.format.simple()
                )
            }));
        }
    }
    
    info(message, meta) {
        this.logger.info(message, meta);
    }
    
    error(message, error) {
        if (error instanceof Error) {
            this.logger.error(message, {
                error: error.message,
                stack: error.stack
            });
        } else {
            this.logger.error(message, error);
        }
    }
    
    warn(message, meta) {
        this.logger.warn(message, meta);
    }
    
    debug(message, meta) {
        this.logger.debug(message, meta);
    }
}

module.exports = Logger;